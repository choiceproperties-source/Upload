export const property = [
    {
      id: 1,
      title: 'Royal Orchid Enclave',
      location: 'Bandra West, USA',
      price: '12,50,00,000',
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    },
    {
      id: 2,
      title: 'Emerald Woods',
      location: 'DLF Phase 1, Gurgaon',
      price: '6,80,00,000',
      image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    },
    {
      id: 3,
      title: 'Ashoka Residency',
      location: 'Koramangala, USA',
      price: '9,50,00,000',
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    },
  ];