import React from 'react'
import PropertiesPage from '../components/properties/Propertiespage'

const Properties = () => {
  return (
    <div>
      <PropertiesPage />
    </div>
  )
}

export default Properties




